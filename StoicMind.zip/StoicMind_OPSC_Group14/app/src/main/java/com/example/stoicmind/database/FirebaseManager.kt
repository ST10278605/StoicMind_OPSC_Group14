package com.example.stoicmind.database

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.stoicmind.models.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val client = OkHttpClient()

    companion object {
        private const val TAG = "FirebaseManager"

        private const val CLOUD_NAME = "komqlp72"
        private const val UPLOAD_PRESET = "stoic_profile_upload"

        private const val CLOUDINARY_URL =
            "https://api.cloudinary.com/v1_1/$CLOUD_NAME/image/upload"
    }

    // --------------------------------------------------
    // FIREBASE AUTHENTICATION
    // --------------------------------------------------

    suspend fun registerUser(
        email: String,
        password: String
    ): Result<User> {
        return try {
            val result = auth.createUserWithEmailAndPassword(
                email,
                password
            ).await()

            val firebaseUser = result.user
                ?: throw Exception("User registration failed")

            val user = User(
                id = firebaseUser.uid,
                email = email
            )

            firestore.collection("users")
                .document(firebaseUser.uid)
                .set(user)
                .await()

            Result.success(user)

        } catch (e: Exception) {
            Log.e(TAG, "Registration failed", e)
            Result.failure(e)
        }
    }

    suspend fun loginUser(
        email: String,
        password: String
    ): Result<User> {
        return try {
            val result = auth.signInWithEmailAndPassword(
                email,
                password
            ).await()

            val firebaseUser = result.user
                ?: throw Exception("Login failed")

            val user = getUser(firebaseUser.uid)

            Result.success(user)

        } catch (e: Exception) {
            Log.e(TAG, "Login failed", e)
            Result.failure(e)
        }
    }

    suspend fun googleSignIn(
        idToken: String
    ): Result<User> {
        return try {
            val credential = GoogleAuthProvider.getCredential(
                idToken,
                null
            )

            val result = auth.signInWithCredential(
                credential
            ).await()

            val firebaseUser = result.user
                ?: throw Exception("Google sign-in failed")

            val user = User(
                id = firebaseUser.uid,
                email = firebaseUser.email ?: ""
            )

            firestore.collection("users")
                .document(firebaseUser.uid)
                .set(user, SetOptions.merge())
                .await()

            Result.success(user)

        } catch (e: Exception) {
            Log.e(TAG, "Google sign-in failed", e)
            Result.failure(e)
        }
    }

    fun logout() {
        auth.signOut()
    }

    fun getCurrentUserId(): String? {
        return auth.currentUser?.uid
    }

    // --------------------------------------------------
    // USER PROFILE
    // --------------------------------------------------

    suspend fun saveUser(user: User) {
        firestore.collection("users")
            .document(user.id)
            .set(user, SetOptions.merge())
            .await()
    }

    suspend fun getUser(userId: String): User {
        val document = firestore.collection("users")
            .document(userId)
            .get()
            .await()

        return document.toObject(User::class.java)
            ?: throw Exception("User profile not found")
    }

    // --------------------------------------------------
    // CLOUDINARY PROFILE IMAGE UPLOAD
    // --------------------------------------------------

    suspend fun uploadProfileImage(
        userId: String,
        imageUri: Uri
    ): Result<String> {

        return withContext(Dispatchers.IO) {
            try {
                val imageBytes = context.contentResolver
                    .openInputStream(imageUri)
                    ?.use { it.readBytes() }
                    ?: throw Exception("Could not read selected image")

                if (imageBytes.isEmpty()) {
                    throw Exception("Selected image is empty")
                }

                val mimeType = context.contentResolver
                    .getType(imageUri)
                    ?: "image/jpeg"

                val imageBody = imageBytes.toRequestBody(
                    mimeType.toMediaType()
                )

                val multipartBody = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(
                        "upload_preset",
                        UPLOAD_PRESET
                    )
                    .addFormDataPart(
                        "folder",
                        "stoic-profile-images"
                    )
                    .addFormDataPart(
                        "public_id",
                        "${userId}_${UUID.randomUUID()}"
                    )
                    .addFormDataPart(
                        "file",
                        "profile_image.jpg",
                        imageBody
                    )
                    .build()

                val request = Request.Builder()
                    .url(CLOUDINARY_URL)
                    .post(multipartBody)
                    .build()

                val response = client.newCall(request).execute()

                val responseBody = response.body?.string()
                    ?: throw Exception("Empty Cloudinary response")

                if (!response.isSuccessful) {
                    throw Exception(
                        "Cloudinary upload failed: $responseBody"
                    )
                }

                val json = JSONObject(responseBody)

                val imageUrl = json.optString("secure_url")

                if (imageUrl.isBlank()) {
                    throw Exception("Cloudinary did not return an image URL")
                }

                // Save the uploaded image URL in Firestore.
                firestore.collection("users")
                    .document(userId)
                    .set(
                        mapOf("profileImageUrl" to imageUrl),
                        SetOptions.merge()
                    )
                    .await()

                Result.success(imageUrl)

            } catch (e: Exception) {
                Log.e(TAG, "Profile image upload failed", e)
                Result.failure(e)
            }
        }
    }

    // --------------------------------------------------
    // JOURNAL ENTRIES
    // --------------------------------------------------

    suspend fun saveJournalEntry(
        entry: JournalEntry
    ): Result<String> {
        return try {
            val document = firestore.collection("journal")
                .document()

            document.set(entry).await()

            Result.success(document.id)

        } catch (e: Exception) {
            Log.e(TAG, "Saving journal entry failed", e)
            Result.failure(e)
        }
    }

    suspend fun getJournalEntries(
        userId: String
    ): List<JournalEntry> {
        return try {
            val snapshot = firestore.collection("journal")
                .whereEqualTo("userId", userId)
                .get()
                .await()

            snapshot.documents.mapNotNull {
                it.toObject(JournalEntry::class.java)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Getting journal entries failed", e)
            emptyList()
        }
    }

    // --------------------------------------------------
    // HABITS
    // --------------------------------------------------

    suspend fun saveHabit(
        habit: Habit
    ): Result<String> {
        return try {
            val document = firestore.collection("habits")
                .document()

            document.set(habit).await()

            Result.success(document.id)

        } catch (e: Exception) {
            Log.e(TAG, "Saving habit failed", e)
            Result.failure(e)
        }
    }

    suspend fun getHabits(
        userId: String
    ): List<Habit> {
        return try {
            val snapshot = firestore.collection("habits")
                .whereEqualTo("userId", userId)
                .get()
                .await()

            snapshot.documents.mapNotNull {
                it.toObject(Habit::class.java)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Getting habits failed", e)
            emptyList()
        }
    }

    // --------------------------------------------------
    // MOOD TRACKING
    // --------------------------------------------------

    suspend fun saveMood(
        mood: MoodCheckIn
    ): Result<String> {
        return try {
            val document = firestore.collection("moods")
                .document()

            document.set(mood).await()

            Result.success(document.id)

        } catch (e: Exception) {
            Log.e(TAG, "Saving mood failed", e)
            Result.failure(e)
        }
    }

    suspend fun getMoods(
        userId: String
    ): List<MoodCheckIn> {
        return try {
            val snapshot = firestore.collection("moods")
                .whereEqualTo("userId", userId)
                .get()
                .await()

            snapshot.documents.mapNotNull {
                it.toObject(MoodCheckIn::class.java)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Getting moods failed", e)
            emptyList()
        }
    }

    // --------------------------------------------------
    // ACHIEVEMENTS
    // --------------------------------------------------

    suspend fun getAchievements(
        userId: String
    ): List<Achievement> {
        return try {
            val snapshot = firestore.collection("achievements")
                .whereEqualTo("userId", userId)
                .get()
                .await()

            snapshot.documents.mapNotNull {
                it.toObject(Achievement::class.java)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Getting achievements failed", e)
            emptyList()
        }
    }
}